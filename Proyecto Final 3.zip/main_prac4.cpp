//Semestre 2017 - 2
//************************************************************//
//************************************************************//
//************** Alumno (s): *********************************//
//*************											******//
//*************											******//
//************************************************************//
#include "Main.h"

float transZ = -5.0f;
float transX = 0.0f;
float angleY = 0.0f;
int screenW = 0.0;
int screenH = 0.0;


void InitGL ( void )     // Inicializamos parametros
{

	//glShadeModel(GL_SMOOTH);							// Habilitamos Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);				// Negro de fondo
	glClearDepth(1.0f);									// Configuramos Depth Buffer
	glEnable(GL_DEPTH_TEST);							// Habilitamos Depth Testing
	//glEnable(GL_LIGHTING);
	glDepthFunc(GL_LEQUAL);								// Tipo de Depth Testing a realizar
	//glEnable ( GL_COLOR_MATERIAL );
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}


void prisma(void)
{
	GLfloat vertice [8][3] = {
				{0.5 ,-0.5, 0.5},    //Coordenadas V�rtice 0 V0
				{-0.5 ,-0.5, 0.5},    //Coordenadas V�rtice 1 V1
				{-0.5 ,-0.5, -0.5},    //Coordenadas V�rtice 2 V2
				{0.5 ,-0.5, -0.5},    //Coordenadas V�rtice 3 V3
				{0.5 ,0.5, 0.5},    //Coordenadas V�rtice 4 V4
				{0.5 ,0.5, -0.5},    //Coordenadas V�rtice 5 V5
				{-0.5 ,0.5, -0.5},    //Coordenadas V�rtice 6 V6
				{-0.5 ,0.5, 0.5},    //Coordenadas V�rtice 7 V7
				};

		glBegin(GL_POLYGON);	//Front
			glColor3f(1.0,0.0,0.0);
			glVertex3fv(vertice[0]);
			glVertex3fv(vertice[4]);
			glVertex3fv(vertice[7]);
			glVertex3fv(vertice[1]);
		glEnd();

		glBegin(GL_POLYGON);	//Right
			glColor3f(0.0,0.0,1.0);
			glVertex3fv(vertice[0]);
			glVertex3fv(vertice[3]);
			glVertex3fv(vertice[5]);
			glVertex3fv(vertice[4]);
		glEnd();

		glBegin(GL_POLYGON);	//Back
			glColor3f(0.0,1.0,0.0);
			glVertex3fv(vertice[6]);
			glVertex3fv(vertice[5]);
			glVertex3fv(vertice[3]);
			glVertex3fv(vertice[2]);
		glEnd();

		glBegin(GL_POLYGON);  //Left
			glColor3f(1.0,1.0,1.0);
			glVertex3fv(vertice[1]);
			glVertex3fv(vertice[7]);
			glVertex3fv(vertice[6]);
			glVertex3fv(vertice[2]);
		glEnd();

		glBegin(GL_POLYGON);  //Bottom
			glColor3f(0.4,0.2,0.6);
			glVertex3fv(vertice[0]);
			glVertex3fv(vertice[1]);
			glVertex3fv(vertice[2]);
			glVertex3fv(vertice[3]);
		glEnd();

		glBegin(GL_POLYGON);  //Top
			glColor3f(0.8,0.2,0.4);
			glVertex3fv(vertice[4]);
			glVertex3fv(vertice[5]);
			glVertex3fv(vertice[6]);
			glVertex3fv(vertice[7]);
		glEnd();
}
void ejes()
{
	glBegin(GL_LINES);
	glColor3f(1, 0, 0);
	glVertex3f(-10, 0, -1);
	glVertex3f(10, 0, -1);
	glColor3f(0, 1, 0);
	glVertex3f(0, -10, -1);
	glVertex3f(0, 10, -1);
	glColor3f(0, 0, 1);
	glVertex3f(0, -0.1, -10);
	glVertex3f(0, 0.1, 10);
	glEnd();

}

void display(void)   // Creamos la funcion donde se dibuja
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Limiamos pantalla y Depth Buffer
	//glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(0, 0, -5);
	
	//Torso
	glRotatef(angleY, 0, 1.0f, 0);
	ejes();
	glTranslatef(0.0f, 0.0f, 5.0f);
	glTranslatef(transX, 0,transZ);
	glPushMatrix();
	glScalef(3.5f, 3.5f, 1.5f);
	prisma();
	glPopMatrix();
	

	//Cabeza
	glTranslatef(0.0f, 2.5f, 0.0f);
	glPushMatrix();
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
	glScalef(1.0f, 1.5f, 1.0f);
	prisma();
	glPopMatrix();


	//Cuello
	glPushMatrix();
	glTranslatef(0.0f, 0.8f, 0.0f);
	glScalef(1.5f, 1.5f, 1.5f);
	prisma();
	glPopMatrix();

	//brazo derecha
	
	glPushMatrix();
	glTranslatef(3.23f, -3.2f, 0.0f);
	glScalef(1.0f, 2.9f, 1.5f);
	prisma();
	glPopMatrix();

	//brazo derecha arriba

	glPushMatrix();
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(-2.74f, -1.25f, 0.0f);
	glScalef(2.0f, 1.0f, 1.5f);
	prisma();
	glPopMatrix();

	//brazo izquierda

	glPushMatrix();
	glTranslatef(-3.23f, -3.2f, 0.0f);
	glScalef(1.0f, 2.9f, 1.5f);
	prisma();
	glPopMatrix();

	//brazo izquierda arriba

	glPushMatrix();
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(2.74f, -1.25f, 0.0f);
	glScalef(2.0f, 1.0f, 1.5f);
	prisma();
	glPopMatrix();

	//Torso inferior (cintura)
	glPushMatrix();
	glTranslatef(0.0f, -4.75f, 0.0f);
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
	glScalef(3.5f, 1.0f, 1.5f);
	prisma();
	glPopMatrix();

	//pierna derecha

	glPushMatrix();
	glTranslatef(-1.0f, -7.0f, 0.0f);
	glScalef(1.5f, 3.5f, 1.5f);
	prisma();
	glPopMatrix();

	//pierna izquierda

	glPushMatrix();
	glTranslatef(1.0f, -7.0f, 0.0f);
	glScalef(1.5f, 3.5f, 1.5f);
	prisma();
	glPopMatrix();

	//pie izquierda arriba

	glPushMatrix();
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(1.51f, -9.0f, 0.0f);
	glScalef(2.5f, 0.5f, 1.5f);
	prisma();
	glPopMatrix();


	//pie derecha arriba

	glPushMatrix();
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(-1.51f, -9.0f, 0.0f);
	glScalef(2.5f, 0.5f, 1.5f);
	prisma();
	glPopMatrix();

	//espada larga

	glPushMatrix();
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(-7.84f, -4.8f, 0.0f);
	glScalef(10.2f, 0.3f, 1.5f);
	prisma();
	glPopMatrix();

	//mango de la espada (superior)

	glPushMatrix();
	glTranslatef(6.23f, -4.15f, 0.0f);
	glScalef(0.1f, 1.0f, 1.5f);
	prisma();
	glPopMatrix();


	//mango de la espada (inferior)

	glPushMatrix();
	glTranslatef(6.23f, -5.45f, 0.0f);
	glScalef(0.1f, 1.0f, 1.5f);
	prisma();
	glPopMatrix();

	//espada mango adorno inferior

	glPushMatrix();
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(-6.3f, -6.0f, 0.0f);
	glScalef(1.0f, 0.1f, 1.5f);
	prisma();
	glPopMatrix();
  								
	//espada mango adorno inferior

	glPushMatrix();
	glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(-6.3f, -3.6f, 0.0f);
	glScalef(1.0f, 0.1f, 1.5f);
	prisma();
	glPopMatrix();


  glutSwapBuffers ( );
  // Swap The Buffers
}

void reshape ( int width , int height )   // Creamos funcion Reshape
{
  if (height==0)										// Prevenir division entre cero
	{
		height=1;
	}

	glViewport(0,0,width,height);	

	glMatrixMode(GL_PROJECTION);						// Seleccionamos Projection Matrix
	glLoadIdentity();

	// Tipo de Vista
	//glOrtho(-5,5,-5,5,0.2,20);	
	glFrustum (-0.1, 0.1,-0.1, 0.1, 0.1, 50.0);

	glMatrixMode(GL_MODELVIEW);							// Seleccionamos Modelview Matrix
}

void keyboard ( unsigned char key, int x, int y )  // Create Keyboard Function
{
	switch ( key ) {
		case 'w':
		case 'W':
			transZ +=0.3f;
			break;
		case 's':
		case 'S':
			transZ -= 0.3f;
			break;
		case 'a':
		case 'A':
			angleY += 0.5;
			break;
		case 'd':
		case 'D':
			angleY -= 0.5;
			break;
		case 27:        // Cuando Esc es presionado...
			exit ( 0 );   // Salimos del programa
		break;        
		default:        // Cualquier otra
		break;
  }
	glutPostRedisplay();
}

void arrow_keys ( int a_keys, int x, int y )  // Funcion para manejo de teclas especiales (arrow keys)
{
  switch ( a_keys ) {
    case GLUT_KEY_UP:		// Presionamos tecla ARRIBA...
		break;
    case GLUT_KEY_DOWN:		// Presionamos tecla ABAJO...
		break;
	case GLUT_KEY_LEFT:
		break;
	case GLUT_KEY_RIGHT:
		break;
    default:
      break;
  }
  glutPostRedisplay();
}


int main ( int argc, char** argv )   // Main Function
{
  glutInit            (&argc, argv); // Inicializamos OpenGL
  //glutInitDisplayMode (GLUT_RGBA | GLUT_SINGLE | GLUT_DEPTH); // Display Mode (Clores RGB y alpha | Buffer Sencillo )
  glutInitDisplayMode (GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH); // Display Mode (Clores RGB y alpha | Buffer Doble )
  screenW = glutGet(GLUT_SCREEN_WIDTH);
  screenH = glutGet(GLUT_SCREEN_HEIGHT);
  glutInitWindowSize  (900, 900);	// Tama�o de la Ventana
  glutInitWindowPosition (0, 0);	//Posicion de la Ventana
  glutCreateWindow    ("Practica 4"); // Nombre de la Ventana
  printf("Resolution H: %i \n", screenW);
  printf("Resolution V: %i \n", screenH);
  InitGL ();						// Parametros iniciales de la aplicacion
  glutDisplayFunc     ( display );  //Indicamos a Glut funci�n de dibujo
  glutReshapeFunc     ( reshape );	//Indicamos a Glut funci�n en caso de cambio de tamano
  glutKeyboardFunc    ( keyboard );	//Indicamos a Glut funci�n de manejo de teclado
  glutSpecialFunc     ( arrow_keys );	//Otras
  glutMainLoop        ( );          // 

  return 0;
}



