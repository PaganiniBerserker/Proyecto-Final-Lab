#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char *argv[])

{
	
	cout << "Numero de argumentos pasados:  " <<argc << endl;
	cout << "Lista de argumentos: " << endl;
	for (int index = 0; index < argc; index++)
	
	{
		
		cout << "index=" << index << ":argumento=" << argv[index] << endl;
		
	}
	
	if (argc >= 3)
	
	{
		int n1 = atoi(argv[1]);
		int n2 = atoi(argv[2]);
		cout << " La suma total de " << n1 << "+" << n2 << "=" << n1+n2 << endl;
		
	}
	
	
}
